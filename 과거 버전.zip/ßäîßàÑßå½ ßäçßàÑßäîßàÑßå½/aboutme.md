---
layout: page
title: About me
subtitle: Let's not think it's impossible even before we start!!
---


<p align="center"><img src="/assets/img/panda_aboutme.png" width="400" alt="프로필 이미지"/></p>

<br><br>
## Who
- Name : Mun_Taeho(PandaMun)
- Job : Student, Studying Computer science at Chosun-University
- Student majoring in computer science
- Studying web development and security.


## Activity
- Email : ansxogh97@gmail.com
- [Naver Blog](https://blog.naver.com/peter5539)
- [Github](https://github.com/pandamun) <img src="https://ghchart.rshah.org/PandaMun" alt="Github Image" style="max-width:100%">
